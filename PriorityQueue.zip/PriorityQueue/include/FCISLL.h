#ifndef FCISLL_H_
#define FCISLL_H_
#include <iostream>
#include <conio.h>
#include <stdlib.h>

using namespace std;

template <class T>
class Node {
public:
	T  data;        // to hold generic data of type T
	Node<T>* next;     // to hold pointer to next item
	Node<T>* prev;
	T item;
	int periority;   // to hold pointer for previous item
	Node()
	{
		next = prev = NULL;
	}
	Node(T dataItem, Node<T>* nextPtr = NULL, Node<T>* prevPtr = NULL)
	{
		data = dataItem; next = nextPtr; prev = prevPtr;
	}
	Node<T>* getNext() { return next; }
	void setNext(Node<T>* ptr) { next = ptr; }
	Node<T>* getPrev() { return prev; }
	void setPrev(Node<T>* ptr) { prev = ptr; }
	T  getData() { return data; }
	void setData(T dataItem) { data = dataItem; }
	template <class TT>
	friend ostream& operator<< (ostream& out, Node<TT> n);
};

/////////////////////////////
template <class T>
class FCISLL {
private:
	Node<T>* head, * tail;
public:
	FCISLL() { head = NULL; tail = NULL; }
	~FCISLL();
	int length = 0;
	bool isEmpty();
	void addToHead(T item);
	void addToTail(T item);
	void addToIndex(T item, int index);
	void removeHead();
	void removeTail();
	void removeFromIndex(int index);
	void removeItem(T item);
	void removeWithPredicate(bool (predicate)( T data));
	bool search(T item);
	template <class TT>
	friend ostream& operator<<(ostream&, FCISLL<TT>);
};

//////////////////////////////

#endif
