#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H
#include<iostream>
#include <cstdlib>
#include "FCISLL.h"
using namespace std;
template <class T>
class priorityqueue
{
    private:
        T item;
        int periority;
        Node<T>*next;
    public:
        FCISLL<T> *mySLL1 = new FCISLL<T>();
        Node<T>*head=NULL;
        priorityqueue();
        priorityqueue(T items,int perioritys);
        void push(T item,int periority);
        void peek();
        void pop();
        void print();
    protected:


};

#endif // PRIORITYQUEUE_H

