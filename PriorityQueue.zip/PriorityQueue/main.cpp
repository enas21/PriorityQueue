#include <iostream>
#include <list>
#include <conio.h>
#include "src\FCISLL.cpp"
#include "src\priorityqueue.cpp"
using namespace std;
int main()
{
    priorityqueue<int> *q=new priorityqueue<int>();
    int value,priority;
    int choice;
    do
    {
        cout<<"Welcome to FCI PriorityQueue using SingleLinkedList"<<endl;
        cout<<"---------------------------------------------------"<<endl;
        cout<<"1-Push into PriorityQueue\n";
        cout<<"2-Pop from PriorityQueue\n";
        cout<<"3-Peek\n";
        cout<<"4-print\n";
        cout<<"5-EXIT\n";
        cout<<"ENTER YOUR CHOICE : ";
        cin>>choice;
        switch(choice)
        {
        case 1:
            {
                cout<<"ENTER THE VALUE OF NODE : ";
                cin>>value;
                cout<<"ENTER THE PRIORITY OF NODE : ";
                cin>>priority;
                q->push(value,priority);
                break;
            }
        case 2:
            {
                q->pop();
                break;
            }
        case 3:
            {
                q->peek();
                break;
            }
        case 4:
            {
                q->print();
                cout<<endl;
                break;
            }
        case 5:
            {
                cout<<"GOODBYE"<<endl;
                break;
            }
        default:
            {
                cout<<"INVALID CHOICE,PLEASE ENTER AGAIN"<<endl;
                break;
            }
        }
    }while(choice!=5);

    return 0;
}

