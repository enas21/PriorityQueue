#include "priorityqueue.h"
#include "FCISLL.h"
template<class T>
priorityqueue<T>::priorityqueue()
{
    item=NULL;
    periority=NULL;
    next=NULL;
}

template<class T>
priorityqueue<T>::priorityqueue(T items,int perioritys)
{
    item=items;
    periority=perioritys;
}

template<class T>
void priorityqueue<T>::push(T item,int periority)
{
    Node<T>*temb=new Node<T>();
    temb->item=item;
    temb->periority=periority;
    temb->next=NULL;
    if(head==NULL)
    {
        head=temb;
        return;//out of function push
    }
    //1 2 3
    Node<T> *temb1=new Node<T>();
    temb1=head;
    Node<T> *prev=NULL;
        while(temb1!=NULL&&temb1->periority < periority)
        {
            prev=temb1;
            temb1=temb1->next;
        }
        if(temb==NULL)
        {
            prev->next=temb;
        }
        else
        {
            if(prev==NULL)
            {
                temb->next=head;
                head=temb;
            }
            else
            {
                temb->next=temb1;
                prev->next=temb;
            }
       }
}
template<class T>
void priorityqueue<T>::peek()
{
    if(head!=NULL)
    {
        T data=head->item;
        cout<<data<<endl;
        return;
    }
    cout<<"it's empty"<<endl;
}

template <class T>
void priorityqueue<T>::pop()
{
    if(head!=NULL)
    {
        T data = head->item;
        head=head->next;
        return;
    }
    cout<<"IT's empty list"<<endl;
}

template<class T>
void priorityqueue<T>::print()
{
    Node<T>*temb=new Node<T>();
    temb=head;
    while(temb!=NULL)
    {
        T data = temb->item;
        cout<<data<<" ";
        temb=temb->next;
    }
}
